# Golden Compass — Deployment Guide

## Environment Variables

Copy `.env.example` to `.env` and fill in every value before deploying.

| Variable | Required | Description |
|---|---|---|
| `SUPABASE_URL` | ✅ | Your Supabase project URL |
| `SUPABASE_PUBLISHABLE_KEY` | ✅ | Supabase anon/public key |
| `SUPABASE_SERVICE_ROLE_KEY` | ✅ | Supabase service role key — server only |
| `MPESA_ENV` | ✅ | `sandbox` or `production` |
| `MPESA_CONSUMER_KEY` | ✅ | Daraja API consumer key |
| `MPESA_CONSUMER_SECRET` | ✅ | Daraja API consumer secret |
| `MPESA_SHORTCODE` | ✅ | PayBill/Till shortcode |
| `MPESA_PASSKEY` | ✅ | STK Push passkey |
| `MPESA_CALLBACK_URL` | ✅ | Public HTTPS URL for STK callbacks |
| `MPESA_B2C_SHORTCODE` | ✅ | B2C shortcode for withdrawals |
| `MPESA_INITIATOR_NAME` | ✅ | B2C initiator name |
| `MPESA_SECURITY_CREDENTIAL` | ✅ | B2C security credential (pre-encrypted) |

## Going Live (Production)

1. Set `MPESA_ENV=production` — API routes automatically switch from `sandbox.safaricom.co.ke` to `api.safaricom.co.ke`.
2. Set `verify_jwt = true` in `supabase/config.toml` (already done — do not revert).
3. Run `supabase db push` to apply all migrations including `20260621000000_atomic_wallet_ops.sql`.
4. Ensure `MPESA_CALLBACK_URL` is publicly reachable by Safaricom.

## Supabase Edge Function

The AI Navigator function (`supabase/functions/ai-navigator`) requires JWT verification (`verify_jwt = true`). The client already passes the JWT via `Authorization: Bearer <token>` header.

## Database Migrations

Run in order:

```bash
supabase db push
```

Key migration: `20260621000000_atomic_wallet_ops.sql` — adds the `debit_wallet` and `invest_from_wallet` RPCs that prevent double-spending race conditions.
