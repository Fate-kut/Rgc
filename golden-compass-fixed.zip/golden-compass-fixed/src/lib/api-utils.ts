// ─────────────────────────────────────────────────────────
// src/lib/api-utils.ts
// Shared server-side helpers for API route handlers.
// ─────────────────────────────────────────────────────────

/** Typed JSON response — eliminates the per-route duplication. */
export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

// ─── Simple in-process rate limiter ──────────────────────
// Cloudflare Workers reset on each request so this is
// single-instance, but it protects against bursts within
// the same isolate lifetime. For multi-instance production
// hardening, replace with a Supabase RPC cooldown check.

interface RateBucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, RateBucket>();

/**
 * Returns true (allow) or false (deny).
 * @param key      e.g. `${userId}:mpesa-stk`
 * @param limit    max requests allowed in the window
 * @param windowMs rolling window in milliseconds (default 60 s)
 */
export function checkRateLimit(key: string, limit: number, windowMs = 60_000): boolean {
  const now = Date.now();
  let bucket = buckets.get(key);

  if (!bucket || now > bucket.resetAt) {
    bucket = { count: 1, resetAt: now + windowMs };
    buckets.set(key, bucket);
    return true;
  }

  bucket.count += 1;
  return bucket.count <= limit;
}
