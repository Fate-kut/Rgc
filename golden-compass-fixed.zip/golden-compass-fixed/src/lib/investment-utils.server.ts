// ─────────────────────────────────────────────────────────
// src/lib/investment-utils.server.ts
// Server-only investment helpers shared across API routes.
// ─────────────────────────────────────────────────────────

import { supabaseAdmin } from "@/integrations/supabase/client.server";

/** Refund units to a user's investment record after a failed withdrawal. */
export async function refundUnits(tx: {
  user_id: string;
  pool_id: string | null;
  amount: number | string;
}): Promise<void> {
  if (!tx.pool_id) return;

  const [{ data: pool }, { data: inv }] = await Promise.all([
    supabaseAdmin
      .from("investment_pools")
      .select("current_nav")
      .eq("id", tx.pool_id)
      .maybeSingle(),
    supabaseAdmin
      .from("user_investments")
      .select("id, current_value, units_owned, invested_amount")
      .eq("user_id", tx.user_id)
      .eq("pool_id", tx.pool_id)
      .maybeSingle(),
  ]);

  const nav = Number(pool?.current_nav ?? 100);
  const refundAmount = Number(tx.amount);
  // Round to 8 decimal places to avoid floating-point drift
  const units = Math.round((refundAmount / nav) * 1e8) / 1e8;

  if (inv) {
    await supabaseAdmin
      .from("user_investments")
      .update({
        current_value: Number(inv.current_value ?? 0) + refundAmount,
        units_owned: Math.round((Number(inv.units_owned ?? 0) + units) * 1e8) / 1e8,
        invested_amount: Number(inv.invested_amount ?? 0) + refundAmount,
      })
      .eq("id", inv.id);
  } else {
    await supabaseAdmin.from("user_investments").insert({
      user_id: tx.user_id,
      pool_id: tx.pool_id,
      current_value: refundAmount,
      units_owned: units,
      invested_amount: refundAmount,
    });
  }
}

/** Refund units AND mark the transaction as failed. */
export async function refundAndFail(
  tx: { id: string; user_id: string; pool_id: string | null; amount: number },
  reason: string,
): Promise<void> {
  await refundUnits(tx);
  await supabaseAdmin
    .from("transactions")
    .update({ status: "failed", mpesa_reference: `FAIL: ${reason}`.slice(0, 200) })
    .eq("id", tx.id);
}

/**
 * Calculate investment units from an amount and NAV.
 * Rounded to 8 decimal places to avoid accumulating float errors.
 */
export function calcUnits(amount: number, nav: number): number {
  return Math.round((amount / nav) * 1e8) / 1e8;
}
