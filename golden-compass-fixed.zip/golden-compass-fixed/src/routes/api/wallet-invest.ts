import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { json, checkRateLimit } from "@/lib/api-utils";
import { calcUnits } from "@/lib/investment-utils.server";

// Move funds from user wallet into a pool atomically via DB RPC.
// Body: { pool_id: string, amount: number }
export const Route = createFileRoute("/api/wallet-invest")({
  server: {
    middleware: [requireSupabaseAuth],
    handlers: {
      POST: async ({ request, context }) => {
        try {
          const { userId } = context as { userId: string };

          // ── Rate limit: 10 invest requests per minute per user ──
          if (!checkRateLimit(`${userId}:wallet-invest`, 10)) {
            return json({ error: "Too many requests. Please slow down." }, 429);
          }

          const body = (await request.json()) as { pool_id?: string; amount?: number };
          const pool_id = String(body.pool_id ?? "");
          const amount = Math.floor(Number(body.amount));
          if (!pool_id) return json({ error: "pool_id required" }, 400);
          if (!amount || amount < 1) return json({ error: "Amount must be at least KES 1" }, 400);

          const { data: pool } = await supabaseAdmin
            .from("investment_pools")
            .select("id, name, current_nav, min_investment, is_active")
            .eq("id", pool_id)
            .maybeSingle();
          if (!pool || !pool.is_active) return json({ error: "Pool not available" }, 400);
          if (amount < Number(pool.min_investment ?? 0))
            return json({ error: `Minimum investment is KES ${pool.min_investment}` }, 400);

          const nav = Number(pool.current_nav ?? 100);
          // Round to 8dp for financial precision
          const units = calcUnits(amount, nav);

          // ── Atomic debit + investment upsert via DB function ──
          const { error: rpcErr } = await supabaseAdmin.rpc("invest_from_wallet", {
            p_user_id: userId,
            p_pool_id: pool_id,
            p_amount: amount,
            p_nav: nav,
            p_units: units,
          });

          if (rpcErr) {
            if (rpcErr.message?.includes("Insufficient balance")) {
              return json({ error: "Insufficient wallet balance" }, 400);
            }
            throw rpcErr;
          }

          // Record confirmed transaction
          await supabaseAdmin.from("transactions").insert({
            user_id: userId,
            pool_id,
            amount,
            type: "invest",
            status: "confirmed",
            confirmed_at: new Date().toISOString(),
          });

          return json({ success: true });
        } catch (e) {
          return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
        }
      },
    },
  },
});
