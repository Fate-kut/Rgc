import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { json } from "@/lib/api-utils";
import { refundUnits, refundAndFail } from "@/lib/investment-utils.server";

// Admin approves a withdrawal → automatically calls M-Pesa B2C to pay out.
// Body: { transaction_id: string, action: "approve" | "reject" }
export const Route = createFileRoute("/api/withdraw-approve")({
  server: {
    middleware: [requireSupabaseAuth],
    handlers: {
      POST: async ({ request, context }) => {
        try {
          const { userId: adminId } = context as { userId: string };

          // ── Admin role check ──
          const { data: roleRow } = await supabaseAdmin
            .from("user_roles")
            .select("role")
            .eq("user_id", adminId)
            .eq("role", "admin")
            .maybeSingle();
          if (!roleRow) return json({ error: "Forbidden" }, 403);

          const body = (await request.json()) as {
            transaction_id?: string;
            action?: "approve" | "reject";
          };
          const txId = String(body.transaction_id ?? "");
          const action = body.action;
          if (!txId || (action !== "approve" && action !== "reject"))
            return json({ error: "Invalid input" }, 400);

          const { data: tx } = await supabaseAdmin
            .from("transactions")
            .select("id, user_id, pool_id, amount, status, type, payout_phone")
            .eq("id", txId)
            .maybeSingle();
          if (!tx) return json({ error: "Transaction not found" }, 404);
          if (tx.type !== "withdrawal") return json({ error: "Not a withdrawal" }, 400);
          if (tx.status !== "pending") return json({ error: "Already processed" }, 400);

          if (action === "reject") {
            await refundUnits(tx);
            await supabaseAdmin.from("transactions").update({ status: "failed" }).eq("id", txId);
            return json({ success: true, status: "failed" });
          }

          // ── APPROVE → trigger B2C payout ──
          if (!tx.payout_phone) {
            return json({ error: "Missing payout phone on transaction" }, 400);
          }

          const mpesaBase =
            process.env.MPESA_ENV === "production"
              ? "https://api.safaricom.co.ke"
              : "https://sandbox.safaricom.co.ke";

          const initiator = process.env.MPESA_INITIATOR_NAME || "testapi";
          const securityCredential =
            process.env.MPESA_SECURITY_CREDENTIAL ||
            "VlmZbZ4HgZeC1qMXcMU2Z4f5o3vbHXSrMrEhlIEGu+Sx5TZkO+0rlT8I7HoIM2eoCK1m8r4rh8XmlKlhmZ9mTtxk8Q5dCJVvZBzNL2jBXf6cQB6/2XSgqXPgM7vUq+1WVoIqCNsFPvjjkkn4lwHB7GPV/3a4bTl4aCOaUqXr+5oVy7VlPCXOzCdVkzc9pSh+jcRLFLSnP4PZxKOIJsyMIQrEqTVj2N5K1CWl6Hbdh2T6c0bXhz2sxTV6HrhhzXIHGnj+MYEyKy1xAWBC8c3p0lH8oAZJSL4FtAcW7lEEMmENfP0+5pY1+1n0mlS8YjLqMeXFIkkRywrkMwZUySE5DA==";
          const b2cShortcode = process.env.MPESA_B2C_SHORTCODE || "600000";
          const consumerKey = process.env.MPESA_CONSUMER_KEY;
          const consumerSecret = process.env.MPESA_CONSUMER_SECRET;
          const callbackBase = process.env.MPESA_CALLBACK_URL;

          if (!consumerKey || !consumerSecret || !callbackBase) {
            return json({ error: "M-Pesa credentials not configured" }, 500);
          }

          let resultUrl = "";
          let timeoutUrl = "";
          try {
            const u = new URL(callbackBase);
            resultUrl = `${u.origin}/api/mpesa-b2c-result`;
            timeoutUrl = `${u.origin}/api/mpesa-b2c-result`;
          } catch {
            return json({ error: "Invalid MPESA_CALLBACK_URL" }, 500);
          }

          // Mark processing so re-clicks don't double-fire
          await supabaseAdmin
            .from("transactions")
            .update({ status: "processing" })
            .eq("id", txId);

          // OAuth token
          const tokRes = await fetch(
            `${mpesaBase}/oauth/v1/generate?grant_type=client_credentials`,
            { headers: { Authorization: "Basic " + btoa(`${consumerKey}:${consumerSecret}`) } },
          );
          if (!tokRes.ok) {
            await refundAndFail(tx, "M-Pesa auth failed");
            return json({ error: "M-Pesa auth failed" }, 502);
          }
          const { access_token } = (await tokRes.json()) as { access_token: string };

          const b2cBody = {
            OriginatorConversationID: `GC-WD-${tx.id}`,
            InitiatorName: initiator,
            SecurityCredential: securityCredential,
            CommandID: "BusinessPayment",
            Amount: Math.floor(Number(tx.amount)),
            PartyA: b2cShortcode,
            PartyB: tx.payout_phone,
            Remarks: `Golden Compass withdrawal ${tx.id.slice(0, 8)}`,
            QueueTimeOutURL: timeoutUrl,
            ResultURL: resultUrl,
            Occasion: tx.id,
          };

          const b2cRes = await fetch(`${mpesaBase}/mpesa/b2c/v1/paymentrequest`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${access_token}`,
            },
            body: JSON.stringify(b2cBody),
          });
          const b2cData = (await b2cRes.json()) as {
            ResponseCode?: string;
            ConversationID?: string;
            errorMessage?: string;
            ResponseDescription?: string;
          };

          if (!b2cRes.ok || b2cData.ResponseCode !== "0") {
            await refundAndFail(
              tx,
              b2cData.errorMessage || b2cData.ResponseDescription || "B2C request rejected",
            );
            return json(
              { error: b2cData.errorMessage || b2cData.ResponseDescription || "B2C request rejected" },
              502,
            );
          }

          await supabaseAdmin
            .from("transactions")
            .update({ mpesa_checkout_id: b2cData.ConversationID ?? null })
            .eq("id", tx.id);

          return json({
            success: true,
            status: "processing",
            message: "Payout initiated. The user will be paid within seconds.",
          });
        } catch (e) {
          return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
        }
      },
    },
  },
});
