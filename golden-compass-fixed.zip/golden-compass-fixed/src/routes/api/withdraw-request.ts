import { createFileRoute } from "@tanstack/react-router";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { json, checkRateLimit } from "@/lib/api-utils";

// Body: { pool_id: string, amount: number, phone: string }
// Enforces holding period & exit fee. Creates a 'pending' withdrawal transaction
// that admins approve from /admin/transactions (B2C payout).
export const Route = createFileRoute("/api/withdraw-request")({
  server: {
    middleware: [requireSupabaseAuth],
    handlers: {
      POST: async ({ request, context }) => {
        try {
          const { userId } = context as { userId: string };

          // ── Rate limit: 5 withdrawal requests per minute per user ──
          if (!checkRateLimit(`${userId}:withdraw-request`, 5)) {
            return json({ error: "Too many requests. Please slow down." }, 429);
          }

          const body = (await request.json()) as { pool_id?: string; amount?: number; phone?: string };
          const pool_id = String(body.pool_id ?? "");
          const amount = Number(body.amount);
          const phoneRaw = String(body.phone ?? "").replace(/\D/g, "");
          let phone = phoneRaw;
          if (phone.startsWith("0")) phone = "254" + phone.slice(1);
          else if (phone.startsWith("7") || phone.startsWith("1")) phone = "254" + phone;
          if (!pool_id || !amount || amount <= 0) return json({ error: "Invalid input" }, 400);
          if (!/^254(7|1)\d{8}$/.test(phone)) return json({ error: "Invalid M-Pesa phone number" }, 400);

          const [{ data: pool }, { data: inv }] = await Promise.all([
            supabaseAdmin
              .from("investment_pools")
              .select("id, name, exit_fee_percent, holding_period_days")
              .eq("id", pool_id)
              .maybeSingle(),
            supabaseAdmin
              .from("user_investments")
              .select("id, current_value, units_owned, invested_amount, created_at")
              .eq("user_id", userId)
              .eq("pool_id", pool_id)
              .maybeSingle(),
          ]);
          if (!pool) return json({ error: "Pool not found" }, 404);
          if (!inv) return json({ error: "You have no holdings in this pool" }, 400);

          const currentValue = Number(inv.current_value ?? 0);
          if (amount > currentValue)
            return json({ error: `Maximum withdrawable: KES ${currentValue.toFixed(2)}` }, 400);

          // Holding period check
          const lockDays = Number(pool.holding_period_days ?? 0);
          if (lockDays > 0 && inv.created_at) {
            const ageMs = Date.now() - new Date(inv.created_at).getTime();
            const daysHeld = ageMs / (1000 * 60 * 60 * 24);
            if (daysHeld < lockDays) {
              const remaining = Math.ceil(lockDays - daysHeld);
              return json(
                { error: `Locked for ${remaining} more day${remaining === 1 ? "" : "s"}` },
                400
              );
            }
          }

          // Exit fee calculation
          const feePct = Number(pool.exit_fee_percent ?? 0);
          const fee = Math.round((amount * feePct) / 100 * 100) / 100; // round to cents
          const net = Math.round((amount - fee) * 100) / 100;

          // Create pending withdrawal
          const { data: tx, error: txErr } = await supabaseAdmin
            .from("transactions")
            .insert({
              user_id: userId,
              pool_id,
              amount: net,       // net payout
              type: "withdrawal",
              status: "pending",
              payout_phone: phone,
            })
            .select("id")
            .single();
          if (txErr || !tx) return json({ error: "Failed to record request" }, 500);

          // Reserve units immediately — prevents double-spending while pending
          const ratio = currentValue > 0 ? amount / currentValue : 0;
          const unitsBurned = Math.round(Number(inv.units_owned ?? 0) * ratio * 1e8) / 1e8;
          await supabaseAdmin
            .from("user_investments")
            .update({
              current_value: Math.round((currentValue - amount) * 100) / 100,
              units_owned: Math.round((Number(inv.units_owned ?? 0) - unitsBurned) * 1e8) / 1e8,
              invested_amount: Math.max(0, Math.round((Number(inv.invested_amount ?? 0) - amount) * 100) / 100),
            })
            .eq("id", inv.id);

          return json({
            success: true,
            transaction_id: tx.id,
            gross: amount,
            fee,
            net,
            message: `Withdrawal of KES ${net.toFixed(2)} requested (KES ${fee.toFixed(2)} exit fee). Pending admin approval.`,
          });
        } catch (e) {
          return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
        }
      },
    },
  },
});
