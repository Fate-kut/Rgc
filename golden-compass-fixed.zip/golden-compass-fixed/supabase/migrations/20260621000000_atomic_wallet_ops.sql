-- ============================================================
-- Atomic wallet debit — prevents race-condition double-spending
-- Returns the new balance; raises if insufficient funds.
-- ============================================================
CREATE OR REPLACE FUNCTION debit_wallet(p_user_id UUID, p_amount DECIMAL)
RETURNS DECIMAL
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_bal DECIMAL;
BEGIN
  UPDATE profiles
     SET wallet_balance = wallet_balance - p_amount
   WHERE id = p_user_id
     AND wallet_balance >= p_amount
  RETURNING wallet_balance INTO new_bal;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Insufficient balance';
  END IF;

  RETURN new_bal;
END;
$$;

-- ============================================================
-- Atomic invest: debit wallet + upsert user_investments in one
-- transaction. Returns new wallet balance.
-- ============================================================
CREATE OR REPLACE FUNCTION invest_from_wallet(
  p_user_id UUID,
  p_pool_id  UUID,
  p_amount   DECIMAL,
  p_nav      DECIMAL,
  p_units    DECIMAL   -- pre-calculated by caller (amount / nav), 8dp
)
RETURNS DECIMAL
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_bal DECIMAL;
BEGIN
  -- 1. Debit wallet atomically
  UPDATE profiles
     SET wallet_balance = wallet_balance - p_amount
   WHERE id = p_user_id
     AND wallet_balance >= p_amount
  RETURNING wallet_balance INTO new_bal;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Insufficient balance';
  END IF;

  -- 2. Upsert investment record
  INSERT INTO user_investments (user_id, pool_id, invested_amount, current_value, units_owned)
  VALUES (p_user_id, p_pool_id, p_amount, p_amount, p_units)
  ON CONFLICT (user_id, pool_id)
  DO UPDATE SET
    invested_amount = user_investments.invested_amount + p_amount,
    current_value   = user_investments.current_value   + p_amount,
    units_owned     = user_investments.units_owned     + p_units;

  RETURN new_bal;
END;
$$;
